
public class PrintStringsThread implements Runnable {
    
    Thread thread;
    String str1, str2;

    // Use TwoStrings a static object so that it is shared
    // by all PrintStringsThread - this is just a demo
    // purpose - to force a single lock object for all
    // threads
    static TwoStrings two = new TwoStrings();
    
    PrintStringsThread(String str1, String str2) {
        this.str1 = str1;
        this.str2 = str2;
        thread = new Thread(this);
        thread.start();
    }
    
    public void run() {
        two.print(str1, str2);
    }
    
}
